--------------------------------------------------------
--  File created - Saturday-July-30-2016
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table WHOLESALE_USAGE_RIGHTS_LOG
--------------------------------------------------------

  CREATE TABLE WHOLESALE_USAGE_RIGHTS_LOG
   (	USER_ID NUMERIC DEFAULT 0,
	SHOOT_ID VARCHAR(50),
	STATUS NUMERIC DEFAULT 0,
	CREATED_BY VARCHAR(10),
	CREATED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP,
	MODIFIED_BY VARCHAR(10),
	MODIFIED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP
   );
--------------------------------------------------------
--  DDL for Index WHOLESALE_LOG_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX WHOLESALE_LOG_PK ON WHOLESALE_USAGE_RIGHTS_LOG (USER_ID, SHOOT_ID);
--------------------------------------------------------
--  Constraints for Table WHOLESALE_USAGE_RIGHTS_LOG
--------------------------------------------------------

  ALTER TABLE WHOLESALE_USAGE_RIGHTS_LOG ADD CONSTRAINT WHOLESALE_LOG_PK PRIMARY KEY (USER_ID, SHOOT_ID);
  ALTER TABLE WHOLESALE_USAGE_RIGHTS_LOG MODIFY (MODIFIED_BY NOT NULL );
  ALTER TABLE WHOLESALE_USAGE_RIGHTS_LOG MODIFY (CREATED_BY NOT NULL );
  ALTER TABLE WHOLESALE_USAGE_RIGHTS_LOG MODIFY (SHOOT_ID NOT NULL );
  ALTER TABLE WHOLESALE_USAGE_RIGHTS_LOG MODIFY (USER_ID NOT NULL );
--------------------------------------------------------
--  Ref Constraints for Table WHOLESALE_USAGE_RIGHTS_LOG
--------------------------------------------------------

  ALTER TABLE WHOLESALE_USAGE_RIGHTS_LOG ADD CONSTRAINT WHOLESALE_LOG_USER_FK FOREIGN KEY (USER_ID)
	  REFERENCES WHOLESALE_USERS (USER_ID) ;
