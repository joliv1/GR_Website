--------------------------------------------------------
--  File created - Saturday-July-30-2016
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table WHOLESALE_SYNC_FILES
--------------------------------------------------------

  CREATE TABLE WHOLESALE_SYNC_FILES
   (	FILE_PATH VARCHAR(256),
	NUMBER_OF_FILES NUMERIC DEFAULT 0,
	STATUS NUMERIC DEFAULT 0,
	CREATED_BY VARCHAR(10),
	CREATED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP,
	MODIFIED_BY VARCHAR(10),
	MODIFIED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP
   );
--------------------------------------------------------
--  DDL for Index WHOLESALE_SYNC_FILES_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX WHOLESALE_SYNC_FILES_PK ON WHOLESALE_SYNC_FILES (FILE_PATH) ;
--------------------------------------------------------
--  Constraints for Table WHOLESALE_SYNC_FILES
--------------------------------------------------------

  ALTER TABLE WHOLESALE_SYNC_FILES ADD CONSTRAINT WHOLESALE_SYNC_FILES_PK PRIMARY KEY (FILE_PATH);
  ALTER TABLE WHOLESALE_SYNC_FILES MODIFY (MODIFIED_BY NOT NULL );
  ALTER TABLE WHOLESALE_SYNC_FILES MODIFY (CREATED_BY NOT NULL );
  ALTER TABLE WHOLESALE_SYNC_FILES MODIFY (NUMBER_OF_FILES NOT NULL );
  ALTER TABLE WHOLESALE_SYNC_FILES MODIFY (FILE_PATH NOT NULL );
