--------------------------------------------------------
--  File created - Saturday-July-30-2016
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table WHOLESALE_ACCOUNTS
--------------------------------------------------------

  CREATE TABLE WHOLESALE_ACCOUNTS
   (	ACCOUNT_ID NUMERIC DEFAULT 0,
	ACCOUNT_FOLDER_NAME VARCHAR(20),
	BRAND_ID VARCHAR(20),
	ACCOUNT_NAME VARCHAR(100) DEFAULT ' ',
	STATUS NUMERIC DEFAULT 0,
	CREATED_BY VARCHAR(10),
	CREATED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP,
	MODIFIED_BY VARCHAR(10),
	MODIFIED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP
);
--------------------------------------------------------
--  DDL for Index WHOLESALE_ACCOUNTS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX WHOLESALE_ACCOUNTS_PK ON WHOLESALE_ACCOUNTS (ACCOUNT_ID);
--------------------------------------------------------
--  DDL for Index WHOLESALE_ACCOUNTS_UNIQUE
--------------------------------------------------------

  CREATE UNIQUE INDEX WHOLESALE_ACCOUNTS_UNIQUE ON WHOLESALE_ACCOUNTS (ACCOUNT_FOLDER_NAME, BRAND_ID);

--------------------------------------------------------
--  Constraints for Table WHOLESALE_ACCOUNTS
--------------------------------------------------------

  ALTER TABLE WHOLESALE_ACCOUNTS ADD CONSTRAINT WHOLESALE_ACCOUNTS_UNIQUE UNIQUE (ACCOUNT_FOLDER_NAME, BRAND_ID);
  ALTER TABLE WHOLESALE_ACCOUNTS ADD CONSTRAINT WHOLESALE_ACCOUNTS_PK PRIMARY KEY (ACCOUNT_ID);
  ALTER TABLE WHOLESALE_ACCOUNTS MODIFY (MODIFIED_BY NOT NULL );
  ALTER TABLE WHOLESALE_ACCOUNTS MODIFY (CREATED_BY NOT NULL );
  ALTER TABLE WHOLESALE_ACCOUNTS MODIFY (BRAND_ID NOT NULL );
  ALTER TABLE WHOLESALE_ACCOUNTS MODIFY (ACCOUNT_FOLDER_NAME NOT NULL );
  ALTER TABLE WHOLESALE_ACCOUNTS MODIFY (ACCOUNT_ID NOT NULL );
--------------------------------------------------------
--  Ref Constraints for Table WHOLESALE_ACCOUNTS
--------------------------------------------------------

  ALTER TABLE WHOLESALE_ACCOUNTS ADD CONSTRAINT WHOLESALE_ACCOUNTS_BRAND_FK FOREIGN KEY (BRAND_ID)
	  REFERENCES WHOLESALE_BRANDS (BRAND_ID) ;
