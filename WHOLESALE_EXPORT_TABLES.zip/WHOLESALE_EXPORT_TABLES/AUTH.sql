--------------------------------------------------------
--  File created - Saturday-July-30-2016
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table WHOLESALE_AUTH
--------------------------------------------------------

  CREATE TABLE WHOLESALE_AUTH
   (	USER_ID NUMERIC,
	USER_PASSWORD VARCHAR(80) DEFAULT NULL,
	USER_SALT VARCHAR(80) DEFAULT NULL,
	USER_TOKEN VARCHAR(80) DEFAULT NULL,
	USER_API_KEY VARCHAR(80) DEFAULT NULL,
	USER_API_SECRET VARCHAR(40) DEFAULT NULL,
	STATUS NUMERIC DEFAULT 0,
	CREATED_BY VARCHAR(10),
	CREATED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP,
	MODIFIED_BY VARCHAR(10),
	MODIFIED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP
   );
--------------------------------------------------------
--  DDL for Index WHOLESALE_AUTH_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX WHOLESALE_AUTH_PK ON WHOLESALE_AUTH (USER_ID);
--------------------------------------------------------
--  Constraints for Table WHOLESALE_AUTH
--------------------------------------------------------

  ALTER TABLE WHOLESALE_AUTH ADD CONSTRAINT WHOLESALE_AUTH_PK PRIMARY KEY (USER_ID);
  ALTER TABLE WHOLESALE_AUTH MODIFY (MODIFIED_BY NOT NULL );
  ALTER TABLE WHOLESALE_AUTH MODIFY (CREATED_BY NOT NULL );
  ALTER TABLE WHOLESALE_AUTH MODIFY (USER_ID NOT NULL );
--------------------------------------------------------
--  Ref Constraints for Table WHOLESALE_AUTH
--------------------------------------------------------

  ALTER TABLE WHOLESALE_AUTH ADD CONSTRAINT WHOLESALE_AUTH_FK FOREIGN KEY (USER_ID)
	  REFERENCES WHOLESALE_USERS (USER_ID) ON DELETE CASCADE ;
