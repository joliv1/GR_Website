--------------------------------------------------------
--  File created - Saturday-July-30-2016
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table WHOLESALE_BRANDS
--------------------------------------------------------

  CREATE TABLE WHOLESALE_BRANDS
   (	BRAND_ID VARCHAR(30),
	BRAND_NAME VARCHAR(80) DEFAULT ' ',
	EXPIRE_YEARS NUMERIC DEFAULT 2,
	REPRESENTATIVE VARCHAR(80) DEFAULT ' ',
	STATUS NUMERIC DEFAULT 0,
	CREATED_BY VARCHAR(10),
	CREATED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP,
	MODIFIED_BY VARCHAR(10),
	MODIFIED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP
   );
--------------------------------------------------------
--  DDL for Index WHOLESALE_BRANDS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX WHOLESALE_BRANDS_PK ON WHOLESALE_BRANDS (BRAND_ID);
--------------------------------------------------------
--  Constraints for Table WHOLESALE_BRANDS
--------------------------------------------------------

  ALTER TABLE WHOLESALE_BRANDS ADD CONSTRAINT WHOLESALE_BRANDS_PK PRIMARY KEY (BRAND_ID);
  ALTER TABLE WHOLESALE_BRANDS MODIFY (MODIFIED_BY NOT NULL );
  ALTER TABLE WHOLESALE_BRANDS MODIFY (CREATED_BY NOT NULL );
  ALTER TABLE WHOLESALE_BRANDS MODIFY (EXPIRE_YEARS NOT NULL );
  ALTER TABLE WHOLESALE_BRANDS MODIFY (BRAND_ID NOT NULL );
