--------------------------------------------------------
--  File created - Saturday-July-30-2016
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table WHOLESALE_ERROR_EMAILS
--------------------------------------------------------

  CREATE TABLE WHOLESALE_ERROR_EMAILS
   (	EMAIL_ADDRESS VARCHAR(120),
	STATUS NUMERIC DEFAULT 0,
	CREATED_BY VARCHAR(10),
	CREATED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP,
	MODIFIED_BY VARCHAR(10),
	MODIFIED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP
   );
--------------------------------------------------------
--  DDL for Index WHOLESALE_ERROR_EMAILS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX WHOLESALE_ERROR_EMAILS_PK ON WHOLESALE_ERROR_EMAILS (EMAIL_ADDRESS);
--------------------------------------------------------
--  Constraints for Table WHOLESALE_ERROR_EMAILS
--------------------------------------------------------

  ALTER TABLE WHOLESALE_ERROR_EMAILS ADD CONSTRAINT WHOLESALE_ERROR_EMAILS_PK PRIMARY KEY (EMAIL_ADDRESS);
  ALTER TABLE WHOLESALE_ERROR_EMAILS MODIFY (MODIFIED_BY NOT NULL );
  ALTER TABLE WHOLESALE_ERROR_EMAILS MODIFY (CREATED_BY NOT NULL );
  ALTER TABLE WHOLESALE_ERROR_EMAILS MODIFY (EMAIL_ADDRESS NOT NULL );
